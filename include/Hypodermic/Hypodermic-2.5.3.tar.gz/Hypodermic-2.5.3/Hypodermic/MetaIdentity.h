#pragma once


namespace Hypodermic
{

    template <class T>
    struct MetaIdentity
    {
        typedef T Type;
    };
    
} // namespace Hypodermic