#pragma once


namespace Hypodermic
{

    namespace Tags
    {

        template <class TDependency>
        struct DependencyFactory
        {
        };

    }

} // namespace Hypodermic