#pragma once


namespace Hypodermic
{

    template <class TKey, class TValue>
    struct MetaPair
    {
        typedef TKey Key;
    };
    
} // namespace Hypodermic