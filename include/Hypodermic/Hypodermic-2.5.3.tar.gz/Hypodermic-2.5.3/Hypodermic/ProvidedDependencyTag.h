#pragma once


namespace Hypodermic
{

    namespace Tags
    {

        template <class TDependency, class TProvidedDependency>
        struct ProvidedDependency
        {
        };

    }

} // namespace Hypodermic