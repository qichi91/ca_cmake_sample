#pragma once

#include <vector>

#include "Hypodermic/ActivationHandler.h"


namespace Hypodermic
{

    typedef std::vector< ActivationHandler > ActivationHandlers;

} // namespace Hypodermic